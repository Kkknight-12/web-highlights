import{a as w}from"./theme-constants-DEdWF7Wx.js";(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))o(i);new MutationObserver(i=>{for(const l of i)if(l.type==="childList")for(const s of l.addedNodes)s.tagName==="LINK"&&s.rel==="modulepreload"&&o(s)}).observe(document,{childList:!0,subtree:!0});function n(i){const l={};return i.integrity&&(l.integrity=i.integrity),i.referrerPolicy&&(l.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?l.credentials="include":i.crossOrigin==="anonymous"?l.credentials="omit":l.credentials="same-origin",l}function o(i){if(i.ep)return;i.ep=!0;const l=n(i);fetch(i.href,l)}})();const a={currentTab:null,highlights:[],pageHighlights:0,totalHighlights:0,pageHighlightsList:[],allHighlightsList:[],currentFilter:"page",searchQuery:"",selectedColors:[],undoData:null,undoTimer:null,pendingDeleteId:null,currentView:"list",selectedHighlight:null,pinnedHighlights:[],archivedHighlights:[],hiddenHighlights:[],siteSettings:{},showArchived:!1};function f(e){Object.assign(a,e)}function S(e){try{const t=new URL(e);return t.origin+t.pathname.replace(/\/$/,"")}catch{return e}}function V(e,t=100){return e.length<=t?e:e.substring(0,t)+"..."}function $(e){if(!e)return"Unknown time";const n=Date.now()-e,o=Math.floor(n/6e4),i=Math.floor(n/36e5),l=Math.floor(n/864e5);return o<1?"Just now":o<60?`${o}m ago`:i<24?`${i}h ago`:l<30?`${l}d ago`:new Date(e).toLocaleDateString()}function U(){}function H(e,t=3e3){const n=document.getElementById("undoToast");if(!n)return;const o=n.querySelector(".undo-message"),i=n.querySelector(".undo-button"),l=document.getElementById("undoProgressBar");o&&(o.textContent=e),i&&(i.style.display="none"),l&&(l.style.display="none"),n.style.display="block",setTimeout(()=>{n.style.display="none",i&&(i.style.display="block"),l&&(l.style.display="block")},t)}function F(){document.getElementById("loadingState").style.display="flex",document.getElementById("highlightsList").style.display="none",document.getElementById("emptyStateCurrentPage").style.display="none",document.getElementById("emptyStateGlobal").style.display="none"}function B(){document.getElementById("loadingState").style.display="none"}function R(e){const t=document.getElementById("emptyStateCurrentPage");t.style.display="block",t.querySelector("p").textContent=e}function T(e){const t=document.getElementById("clearFiltersBtn");if(!t)return;const n=e.selectedColors.length>0||e.searchQuery.length>0;t.style.display=n?"flex":"none"}async function b(e){F();try{const t=await chrome.storage.local.get(null),n=[];let o=0;t.optionsMenuState&&(e.pinnedHighlights=t.optionsMenuState.pinnedHighlights||[],e.archivedHighlights=t.optionsMenuState.archivedHighlights||[],e.hiddenHighlights=t.optionsMenuState.hiddenHighlights||[],e.siteSettings=t.optionsMenuState.siteSettings||{});for(const[i,l]of Object.entries(t))i==="settings"||i==="optionsMenuState"||!Array.isArray(l)||Array.isArray(l)&&(l.forEach(s=>{n.push({...s,url:i})}),o+=l.length);if(e.highlights=n,e.allHighlightsList=n,e.totalHighlights=o,e.currentTab&&e.currentTab.url){const i=S(e.currentTab.url),l=t[i]||t[e.currentTab.url]||[];e.pageHighlightsList=Array.isArray(l)?l:[],e.pageHighlights=e.pageHighlightsList.length,console.log("[Popup] Current URL:",i),console.log("[Popup] Page highlights:",e.pageHighlightsList)}return B(),!0}catch(t){return console.error("[Popup] Error loading highlights:",t),B(),R("Failed to load highlights"),!1}}function W(e,t){chrome.storage.onChanged.addListener((n,o)=>{o==="local"&&n.highlights&&e().then(t)})}async function k(e){try{const t={pinnedHighlights:e.pinnedHighlights||[],archivedHighlights:e.archivedHighlights||[],hiddenHighlights:e.hiddenHighlights||[],siteSettings:e.siteSettings||{}};return await chrome.storage.local.set({optionsMenuState:t}),!0}catch(t){return console.error("[Popup] Error saving options menu state:",t),!1}}async function z(e){const t=e.pageHighlightsList.length>0,n=e.allHighlightsList.length>0;if(!t&&!n){alert("No highlights to export");return}Q(e,t)}function Q(e,t,n){const o=document.createElement("div");o.className="export-dialog-overlay";const i=document.createElement("div");i.className="export-dialog";const l=e.pageHighlightsList.length,s=e.allHighlightsList.length;i.innerHTML=`
    <h3>Export Highlights</h3>
    <p>Choose export format and scope</p>
    
    <div class="export-options">
      <h4 style="margin: 0 0 8px 0; font-size: 14px; color: var(--color-text-secondary);">Format:</h4>
      <label class="export-option">
        <input type="radio" name="format" value="json" checked>
        <span>JSON (Full data with metadata)</span>
      </label>
      <label class="export-option">
        <input type="radio" name="format" value="text">
        <span>Plain Text (Simple text list)</span>
      </label>
    </div>
    
    <div class="export-scope">
      <h4 style="margin: 0 0 8px 0; font-size: 14px; color: var(--color-text-secondary);">Scope:</h4>
      <label class="export-option">
        <input type="radio" name="scope" value="page" ${t?"checked":"disabled"}>
        <span>Current page only (${l} highlight${l!==1?"s":""})</span>
      </label>
      <label class="export-option">
        <input type="radio" name="scope" value="all" ${t?"":"checked"}>
        <span>All pages (${s} highlight${s!==1?"s":""})</span>
      </label>
    </div>
    
    <div class="export-actions">
      <button class="export-cancel">Cancel</button>
      <button class="export-confirm">Export</button>
    </div>
  `,o.appendChild(i),document.body.appendChild(o),i.querySelector(".export-cancel").addEventListener("click",()=>{o.remove()}),i.querySelector(".export-confirm").addEventListener("click",()=>{const d=i.querySelector('input[name="format"]:checked').value,r=i.querySelector('input[name="scope"]:checked').value;o.remove();const c=r==="page"?e.pageHighlightsList:e.allHighlightsList;d==="json"?G(c,r,e):J(c,r,e)}),o.addEventListener("click",d=>{d.target===o&&o.remove()})}function G(e,t,n){const o={exportDate:new Date().toISOString(),exportScope:t==="page"?"Current page":"All pages",source:t==="page"?n.currentTab.url:"Multiple pages",totalHighlights:e.length,highlights:e.map(r=>({text:r.text,url:r.url,color:r.color,timestamp:r.timestamp,dateCreated:new Date(r.timestamp).toLocaleString(),note:r.note||""}))},i=new Blob([JSON.stringify(o,null,2)],{type:"application/json"}),l=URL.createObjectURL(i),s=new Date().toISOString().split("T")[0],d=t==="page"?"current-page":"all-pages";chrome.downloads.download({url:l,filename:`web-highlights-${d}-${s}.json`,saveAs:!0})}function J(e,t,n){let o=`Web Highlights Export
`;o+=`${"=".repeat(50)}
`,o+=`Export Date: ${new Date().toLocaleString()}
`,o+=`Total Highlights: ${e.length}
`,o+=`Scope: ${t==="page"?n.currentTab.url:"All pages"}
`,o+=`${"=".repeat(50)}

`;const i={};e.forEach(c=>{const u=c.url||"Unknown URL";i[u]||(i[u]=[]),i[u].push(c)}),Object.entries(i).forEach(([c,u])=>{o+=`📍 Page: ${c}
`,o+=`${"-".repeat(40)}

`,u.forEach((h,v)=>{const g=new Date(h.timestamp).toLocaleDateString(),j=new Date(h.timestamp).toLocaleTimeString();o+=`${v+1}. [${h.color.toUpperCase()}] - ${g} at ${j}
`,o+=`   "${h.text}"
`,h.note&&h.note.trim()&&(o+=`   📝 Note: ${h.note}
`),o+=`
`}),o+=`
`}),o+=`${"=".repeat(50)}
`,o+=`End of Export
`;const l=new Blob([o],{type:"text/plain;charset=utf-8"}),s=URL.createObjectURL(l),d=new Date().toISOString().split("T")[0],r=t==="page"?"current-page":"all-pages";chrome.downloads.download({url:s,filename:`web-highlights-${r}-${d}.txt`,saveAs:!0})}let x=null;function K(e){x=e}function _(e){e.undoTimer&&(clearTimeout(e.undoTimer),e.undoTimer=null);const t=document.getElementById("undoToast"),n=document.getElementById("undoProgressBar");n.style.animation="none",n.offsetHeight,n.style.animation="undoCountdown 5s linear forwards",t.style.display="block",setTimeout(()=>{t.classList.add("show")},10),e.undoTimer=setTimeout(async()=>{P(e),x&&await x(e),e.undoData=null,e.pendingDeleteId=null,e.renderCallback&&e.renderCallback()},5e3)}function P(e){const t=document.getElementById("undoToast");t.classList.remove("show"),setTimeout(()=>{t.style.display="none"},300),e.undoTimer&&(clearTimeout(e.undoTimer),e.undoTimer=null)}async function X(e){if(!(!e.undoData||!e.pendingDeleteId))try{e.undoTimer&&(clearTimeout(e.undoTimer),e.undoTimer=null);const t=e.pendingDeleteId;e.undoData=null,e.pendingDeleteId=null,P(e);const[n]=await chrome.tabs.query({active:!0,currentWindow:!0});await chrome.tabs.sendMessage(n.id,{action:"removePendingDelete",highlightId:t}),e.renderCallback&&e.renderCallback(),console.log("[Popup] Highlight delete cancelled via undo")}catch(t){console.error("[Popup] Error handling undo:",t)}}async function A(e,t){try{if(!t.currentTab||!t.currentTab.url)return;const n=Array.isArray(e)?e:[e],o=n.length===1,i=S(t.currentTab.url);if(o){t.undoData&&t.pendingDeleteId&&await C(t),t.pendingDeleteId=n[0];const l=await chrome.storage.local.get([i,t.currentTab.url]),d=(l[i]||l[t.currentTab.url]||[]).find(r=>r.id===n[0]);if(d){t.undoData={highlight:d,url:i,storageKey:l[i]?i:t.currentTab.url},_(t);const[r]=await chrome.tabs.query({active:!0,currentWindow:!0});chrome.tabs.sendMessage(r.id,{action:"markPendingDelete",highlightId:d.id}),t.renderCallback&&t.renderCallback()}}else{t.undoData&&t.pendingDeleteId&&await C(t);const l=highlights.filter(c=>!n.includes(c.id)),s={},d=result[i]?i:t.currentTab.url;s[d]=l,await chrome.storage.local.set(s);const[r]=await chrome.tabs.query({active:!0,currentWindow:!0});chrome.tabs.sendMessage(r.id,{action:"removeHighlights",highlightIds:n}),await b(t)}}catch(n){console.error("[Popup] Error deleting highlight:",n)}}async function C(e){if(!(!e.undoData||!e.pendingDeleteId))try{const{storageKey:t}=e.undoData,i=((await chrome.storage.local.get(t))[t]||[]).filter(d=>d.id!==e.pendingDeleteId),l={};l[t]=i,await chrome.storage.local.set(l);const[s]=await chrome.tabs.query({active:!0,currentWindow:!0});chrome.tabs.sendMessage(s.id,{action:"removeHighlights",highlightIds:[e.pendingDeleteId]}),e.pendingDeleteId=null,e.undoData=null,await b(e),e.renderCallback&&e.renderCallback()}catch(t){console.error("[Popup] Error executing pending delete:",t)}}async function I(e,t){const o=(e==="page"?t.pageHighlightsList:t.allHighlightsList).length;o!==0&&Y(e,o,t)}function Y(e,t,n){const o=document.createElement("div");o.className="confirmation-dialog-overlay";const i=document.createElement("div");i.className="confirmation-dialog";const l=e==="page"?"Clear Page Highlights?":"Clear All Highlights?",s=e==="page"?`This will permanently delete <span class="highlight-count">${t} highlight${t!==1?"s":""}</span> from the current page.`:`This will permanently delete <span class="highlight-count">ALL ${t} highlight${t!==1?"s":""}</span> from all pages.`;i.innerHTML=`
    <h3>${l}</h3>
    <p>${s}</p>
    <p>This action cannot be undone.</p>
    
    <div class="confirmation-actions">
      <button class="confirmation-cancel">Cancel</button>
      <button class="confirmation-confirm">Clear</button>
    </div>
  `,o.appendChild(i),document.body.appendChild(o),i.querySelector(".confirmation-cancel").addEventListener("click",()=>{o.remove()}),i.querySelector(".confirmation-confirm").addEventListener("click",async()=>{o.remove(),await Z(e,n)}),o.addEventListener("click",d=>{d.target===o&&o.remove()})}async function Z(e,t){try{if(t.undoData&&t.pendingDeleteId&&await C(t),e==="page"){if(!t.currentTab||!t.currentTab.url)return;const n=S(t.currentTab.url),o={};o[n]=[],o[t.currentTab.url]=[],await chrome.storage.local.set(o);const[i]=await chrome.tabs.query({active:!0,currentWindow:!0});chrome.tabs.sendMessage(i.id,{action:"clearAllHighlights"})}else{const n=await chrome.storage.local.get(null),o={};for(const[l,s]of Object.entries(n))l!=="settings"&&Array.isArray(s)&&(o[l]=[]);await chrome.storage.local.set(o);const[i]=await chrome.tabs.query({active:!0,currentWindow:!0});chrome.tabs.sendMessage(i.id,{action:"clearAllHighlights"})}await b(t),t.renderCallback&&t.renderCallback()}catch(n){console.error("[Popup] Error clearing highlights:",n)}}function N(e){const t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.opacity="0",document.body.appendChild(t),t.select(),document.execCommand("copy"),document.body.removeChild(t),console.log("[Popup] Text copied to clipboard")}function ee(e){const t=Date.now(),n=24*60*60*1e3,o=7*n;switch(e.currentFilter){case"page":return e.pageHighlightsList;case"today":return e.allHighlightsList.filter(i=>{const l=i.timestamp||0;return t-l<n});case"week":return e.allHighlightsList.filter(i=>{const l=i.timestamp||0;return t-l<o});case"all":default:return e.allHighlightsList}}function te(e,t){let n=e;if(t.searchQuery&&(n=n.filter(i=>i.text.toLowerCase().includes(t.searchQuery)||i.url&&i.url.toLowerCase().includes(t.searchQuery))),t.selectedColors.length>0&&(n=n.filter(i=>t.selectedColors.includes(i.color))),!t.showArchived){const i=t.archivedHighlights||[];n=n.filter(l=>!i.includes(l.id))}const o=t.hiddenHighlights||[];return n=n.filter(i=>!o.includes(i.id)),n}function ne(e,t){const n=t.pinnedHighlights||[];return[...e].sort((o,i)=>{const l=n.includes(o.id),s=n.includes(i.id);return l&&!s?-1:!l&&s?1:(i.timestamp||0)-(o.timestamp||0)})}const E=500;function ie(e){return w.highlights[e]||w.highlights.yellow}async function D(e,t){try{const n=a.highlights.find(s=>s.id===e);if(!n||!n.url){console.error("[DetailView] Highlight not found or missing URL");return}const i=(await chrome.storage.local.get([n.url]))[n.url]||[],l=i.findIndex(s=>s.id===e);l!==-1&&(i[l].note=t.trim(),await chrome.storage.local.set({[n.url]:i}),n.note=t.trim(),console.log("[DetailView] Note saved for highlight:",e))}catch(n){console.error("[DetailView] Error saving note:",n)}}async function oe(e,t){try{const n=a.highlights.find(s=>s.id===e);if(!n||!n.url){console.error("[DetailView] Highlight not found or missing URL");return}const i=(await chrome.storage.local.get([n.url]))[n.url]||[],l=i.findIndex(s=>s.id===e);if(l!==-1){i[l].color=t,await chrome.storage.local.set({[n.url]:i}),n.color=t;const[s]=await chrome.tabs.query({active:!0,currentWindow:!0});await chrome.tabs.sendMessage(s.id,{action:"changeHighlightColor",highlightId:e,newColor:t}),q(n)}}catch(n){console.error("[DetailView] Error changing color:",n)}}function q(e){const t=document.getElementById("detailViewContainer");t&&(t.innerHTML=`
    <div class="detail-header">
      <button class="back-button" id="backToListBtn">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M19 12H5M5 12l7 7M5 12l7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <span>Back</span>
      </button>
    </div>
    
    <div class="detail-content">
      <!-- Highlight text -->
      <div class="detail-highlight-text" style="border-left: 4px solid ${ie(e.color)};">
        ${e.text}
      </div>
      
      <!-- Metadata -->
      <div class="detail-metadata">
        <span class="detail-timestamp">${$(e.timestamp)}</span>
        <span class="detail-separator">•</span>
        <span class="detail-url" title="${e.url}">${new URL(e.url).hostname}</span>
      </div>
      
      <!-- Note section -->
      <div class="detail-note-section">
        <label for="noteTextarea" class="detail-note-label">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M14 2v6h6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <line x1="16" y1="13" x2="8" y2="13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <line x1="16" y1="17" x2="8" y2="17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <line x1="10" y1="9" x2="8" y2="9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          Note
        </label>
        <textarea 
          id="noteTextarea" 
          class="detail-note-textarea" 
          placeholder="Add a note about this highlight..."
          maxlength="${E}">${e.note||""}</textarea>
        <div class="detail-note-footer">
          <span class="detail-note-counter">${(e.note||"").length}/${E}</span>
          <button class="detail-save-note-btn" id="saveNoteBtn" style="display: none;">Save</button>
        </div>
      </div>
      
      <!-- Color picker -->
      <div class="detail-color-section">
        <label class="detail-color-label">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          Color
        </label>
        <div class="detail-color-picker">
          ${Object.entries(w.highlights).map(([n,o])=>`
            <button class="detail-color-btn ${e.color===n?"active":""}" 
                    data-color="${n}"
                    style="background-color: ${o};"
                    title="${n}">
            </button>
          `).join("")}
        </div>
      </div>
      
      <!-- Actions -->
      <div class="detail-actions">
        <button class="detail-action-btn" id="copyHighlightBtn">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="9" y="9" width="13" height="13" rx="2" ry="2" stroke="currentColor" stroke-width="2"/>
            <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" stroke="currentColor" stroke-width="2"/>
          </svg>
          Copy Text
        </button>
        <button class="detail-action-btn delete" id="deleteHighlightBtn">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          Delete
        </button>
      </div>
    </div>
  `,le(e))}function le(e){const t=document.getElementById("backToListBtn");t&&t.addEventListener("click",L);const n=document.getElementById("noteTextarea"),o=document.getElementById("saveNoteBtn"),i=document.querySelector(".detail-note-counter");if(n){const d=e.note||"";n.addEventListener("input",r=>{const c=r.target.value.length;i&&(i.textContent=`${c}/${E}`),o&&(o.style.display=r.target.value!==d?"block":"none")}),o&&o.addEventListener("click",async()=>{await D(e.id,n.value),o.style.display="none",e.note=n.value}),n.addEventListener("blur",async()=>{n.value!==d&&(await D(e.id,n.value),o&&(o.style.display="none"),e.note=n.value)})}document.querySelectorAll(".detail-color-btn").forEach(d=>{d.addEventListener("click",async r=>{const c=r.target.dataset.color;c!==e.color&&(document.querySelectorAll(".detail-color-btn").forEach(u=>u.classList.remove("active")),r.target.classList.add("active"),await oe(e.id,c))})});const l=document.getElementById("copyHighlightBtn");l&&l.addEventListener("click",()=>{N(e.text)});const s=document.getElementById("deleteHighlightBtn");s&&s.addEventListener("click",async()=>{await A([e.id],a),L()})}function re(e){const t=a.highlights.find(d=>d.id===e);if(!t){console.error("[ViewManager] Highlight not found:",e);return}f({currentView:"detail",selectedHighlight:t});const n=document.querySelector(".highlights-section"),o=document.querySelector(".actions-container"),i=document.querySelector(".filter-container"),l=document.querySelector(".color-filter-container");n&&(n.style.display="none"),o&&(o.style.display="none"),i&&(i.style.display="none"),l&&(l.style.display="none");const s=document.getElementById("detailViewContainer");s&&(s.style.display="flex",q(t))}function L(){f({currentView:"list",selectedHighlight:null});const e=document.querySelector(".highlights-section"),t=document.querySelector(".actions-container"),n=document.querySelector(".filter-container"),o=document.querySelector(".color-filter-container");e&&(e.style.display="flex"),t&&(t.style.display="flex"),n&&(n.style.display="flex"),o&&(o.style.display="flex");const i=document.getElementById("detailViewContainer");i&&(i.style.display="none"),p(a)}function se(){window.addEventListener("popstate",e=>{e.state&&e.state.view==="list"&&L()}),window.history.replaceState({view:"list"},"","")}let y=null;function ae(e,t){const n=document.createElement("div");n.className="options-menu-container";const o=document.createElement("button");o.className="options-menu-btn",o.title="More options",o.innerHTML=`
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="12" cy="5" r="1.5" fill="currentColor"/>
      <circle cx="12" cy="12" r="1.5" fill="currentColor"/>
      <circle cx="12" cy="19" r="1.5" fill="currentColor"/>
    </svg>
  `;const i=document.createElement("div");i.className="options-dropdown",i.style.display="none";const l=t.pinnedHighlights?.includes(e.id),s=t.archivedHighlights?.includes(e.id);return[{id:"pin",label:l?"Unpin from Top":"Pin to Top",icon:`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M19 11h-6V5a1 1 0 0 0-2 0v6H5a1 1 0 0 0 0 2h6v6a1 1 0 0 0 2 0v-6h6a1 1 0 0 0 0-2z" 
          fill="${l?"currentColor":"none"}" 
          stroke="currentColor" 
          stroke-width="2"/>
      </svg>`,action:()=>{const r=[...a.pinnedHighlights],c=r.indexOf(e.id);c===-1?r.push(e.id):r.splice(c,1),f({pinnedHighlights:r}),k(a),a.renderCallback&&a.renderCallback(),m()}},{id:"archive",label:s?"Unarchive":"Archive",icon:`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M21 8v13a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8m18 0-2-5H5L3 8m18 0H3m9 5v5" 
          stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>`,action:()=>{const r=[...a.archivedHighlights],c=r.indexOf(e.id);c===-1?r.push(e.id):r.splice(c,1),f({archivedHighlights:r}),k(a),a.renderCallback&&a.renderCallback(),m()}},{id:"hide",label:"Hide Until Next Visit",icon:`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" 
          stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2"/>
        <path d="M1 1l22 22" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
      </svg>`,action:()=>{const r=[...a.hiddenHighlights];r.includes(e.id)||r.push(e.id),f({hiddenHighlights:r}),a.renderCallback&&a.renderCallback(),m()}},{id:"divider",type:"divider"},{id:"copy-link",label:"Copy Link",icon:`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" 
          stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" 
          stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>`,action:()=>{de(e),m()}},{id:"divider2",type:"divider"},{id:"site-settings",label:"Site Settings",icon:`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2"/>
        <path d="M12 1v6m0 6v6m11-7h-6m-6 0H1" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
      </svg>`,hasSubmenu:!0,submenu:ce(e.url)}].forEach(r=>{if(r.type==="divider"){const c=document.createElement("div");c.className="options-menu-divider",i.appendChild(c)}else{const c=document.createElement("button");c.className="options-menu-item",r.hasSubmenu&&c.classList.add("has-submenu"),c.innerHTML=`
        <span class="menu-item-icon">${r.icon}</span>
        <span class="menu-item-label">${r.label}</span>
        ${r.hasSubmenu?'<span class="submenu-arrow">›</span>':""}
      `,r.hasSubmenu?(c.appendChild(r.submenu),c.addEventListener("mouseenter",()=>{r.submenu.style.display="block"}),c.addEventListener("mouseleave",()=>{r.submenu.style.display="none"})):r.action&&c.addEventListener("click",u=>{u.stopPropagation(),r.action()}),i.appendChild(c)}}),o.addEventListener("click",r=>{r.stopPropagation(),ue(i)}),document.addEventListener("click",O),n.appendChild(o),n.appendChild(i),n}function ce(e){const t=document.createElement("div");t.className="options-submenu",t.style.display="none";const n=new URL(e).hostname,o=a.siteSettings[n]||{};return[{label:o.disabled?"Enable on this site":"Disable on this site",action:()=>{const l={...a.siteSettings};l[n]={...l[n],disabled:!o.disabled},f({siteSettings:l}),k(a),m()}},{label:"Reset UI positions",action:()=>{chrome.storage.local.remove(`positions_${n}`),m()}},{label:o.hidePopup?"Show popup on this site":"Hide popup on this site",action:()=>{const l={...a.siteSettings};l[n]={...l[n],hidePopup:!o.hidePopup},f({siteSettings:l}),k(a),m()}}].forEach(l=>{const s=document.createElement("button");s.className="options-menu-item submenu-item",s.textContent=l.label,s.addEventListener("click",d=>{d.stopPropagation(),l.action()}),t.appendChild(s)}),t}function de(e){const t=`${e.url}#highlight=${e.id}`;navigator.clipboard.writeText(t).then(()=>{M("Link copied to clipboard")}).catch(n=>{console.error("Failed to copy link:",n),M("Failed to copy link")})}function M(e){const t=document.getElementById("undoToast"),n=t.querySelector(".undo-message"),o=t.querySelector(".undo-button");n.textContent=e,o.style.display="none",t.style.display="block",setTimeout(()=>{t.style.display="none",o.style.display="block"},2e3)}function ue(e){const t=e.style.display==="block";y&&y!==e&&(y.style.display="none"),e.style.display=t?"none":"block",y=t?null:e,t||he(e)}function he(e){const t=e.getBoundingClientRect();e.parentElement.getBoundingClientRect(),e.style.right="0",e.style.left="auto",e.style.top="100%",e.style.bottom="auto",t.bottom>window.innerHeight-10&&(e.style.top="auto",e.style.bottom="100%"),t.right>window.innerWidth-10&&(e.style.right="0",e.style.left="auto")}function m(){y&&(y.style.display="none",y=null)}function O(e){e.target.closest(".options-menu-container")||m()}window.addEventListener("unload",()=>{document.removeEventListener("click",O)});function ge(e){return w.highlights[e]||w.highlights.yellow}function pe(e,t,n){const o=document.createElement("div");o.className="highlight-item",t.pendingDeleteId===e.id&&o.classList.add("pending-delete"),t.pinnedHighlights?.includes(e.id)&&o.classList.add("pinned"),t.archivedHighlights?.includes(e.id)&&o.classList.add("archived"),o.dataset.highlightId=e.id;const i=document.createElement("div");i.className="highlight-color-indicator",i.style.backgroundColor=ge(e.color);const l=document.createElement("div");l.className="highlight-content";const s=document.createElement("div");s.className="highlight-text",s.textContent=V(e.text),s.title=e.text;const d=document.createElement("div");d.className="highlight-metadata";const r=document.createElement("span");if(r.className="highlight-timestamp",r.textContent=$(e.timestamp),d.appendChild(r),e.note&&e.note.trim()){const g=document.createElement("span");g.className="highlight-note-indicator",g.innerHTML=`
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M14 2v6h6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <line x1="16" y1="13" x2="8" y2="13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <line x1="16" y1="17" x2="8" y2="17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    `,g.title=e.note.substring(0,50)+(e.note.length>50?"...":""),d.appendChild(document.createTextNode(" • ")),d.appendChild(g)}if(t.pinnedHighlights?.includes(e.id)){const g=document.createElement("span");g.className="highlight-pinned-indicator",g.innerHTML=`
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 2v10m0 0l-3-3m3 3l3-3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <rect x="8" y="14" width="8" height="8" rx="1" fill="currentColor"/>
      </svg>
    `,g.title="Pinned",d.appendChild(document.createTextNode(" • ")),d.appendChild(g)}const c=document.createElement("div");c.className="highlight-actions";const u=document.createElement("button");u.className="highlight-action-btn copy-btn",u.title="Copy text",u.innerHTML=`
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" stroke="currentColor" stroke-width="2"/>
      <rect x="8" y="2" width="8" height="4" rx="1" stroke="currentColor" stroke-width="2"/>
    </svg>
  `,u.addEventListener("click",g=>{g.stopPropagation(),N(e.text)});const h=document.createElement("button");h.className="highlight-action-btn delete-btn",h.title="Delete highlight",h.innerHTML=`
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M3 6h18m-2 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
    </svg>
  `,h.addEventListener("click",g=>{g.stopPropagation(),A(e.id,t)});const v=ae(e,t);return c.appendChild(u),c.appendChild(h),c.appendChild(v),l.appendChild(s),l.appendChild(d),o.appendChild(i),o.appendChild(l),o.appendChild(c),o.addEventListener("click",g=>{g.target.closest(".highlight-actions")||re(e.id)}),o}function p(e){const t=document.getElementById("highlightsList");t.innerHTML="";let n=ee(e);if(n=te(n,e),n.length===0){if(e.searchQuery||e.selectedColors.length>0||e.currentFilter!=="all"){document.getElementById("emptyStateCurrentPage").style.display="block";const i=document.querySelector("#emptyStateCurrentPage p");i.textContent="No highlights found"}else e.totalHighlights===0?document.getElementById("emptyStateGlobal").style.display="block":document.getElementById("emptyStateCurrentPage").style.display="block";t.style.display="none";return}document.getElementById("emptyStateCurrentPage").style.display="none",document.getElementById("emptyStateGlobal").style.display="none",t.style.display="block",ne(n,e).forEach(i=>{const l=pe(i,e);t.appendChild(l)})}async function me(){const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!e||!e.url)return;const n=new URL(e.url).hostname,o=await chrome.storage.local.get("optionsMenuState"),i=o.optionsMenuState?.siteSettings?.[n]||{},l=document.createElement("div");l.className="site-settings-overlay";const s=document.createElement("div");s.className="site-settings-dialog",s.innerHTML=`
    <h3>Site Settings</h3>
    <p class="site-domain">${n}</p>
    
    <div class="settings-options">
      <label class="setting-option">
        <input type="checkbox" id="disableExtension" ${i.disabled?"checked":""}>
        <span>Disable extension on this site</span>
      </label>
      
      <label class="setting-option">
        <input type="checkbox" id="hideButton" ${i.hideButton?"checked":""}>
        <span>Hide highlight button on this site</span>
      </label>
    </div>
    
    <div class="dialog-actions">
      <button class="dialog-btn cancel-btn" id="cancelSettings">Cancel</button>
      <button class="dialog-btn save-btn" id="saveSettings">Save</button>
    </div>
  `,l.appendChild(s),document.body.appendChild(l),document.getElementById("saveSettings").addEventListener("click",async()=>{const d=document.getElementById("disableExtension").checked,r=document.getElementById("hideButton").checked,c=o.optionsMenuState||{siteSettings:{}};c.siteSettings||(c.siteSettings={}),c.siteSettings[n]={disabled:d,hideButton:r},await chrome.storage.local.set({optionsMenuState:c}),l.remove(),H("Settings saved! Reloading page..."),setTimeout(async()=>{try{await chrome.tabs.reload(e.id),window.close()}catch(u){console.error("[SiteSettings] Failed to reload tab:",u),H("Please reload the page manually to apply changes.")}},500)}),document.getElementById("cancelSettings").addEventListener("click",()=>{l.remove()}),l.addEventListener("click",d=>{d.target===l&&l.remove()})}function ye(){const e=document.getElementById("siteSettingsBtn");e&&e.addEventListener("click",me)}K(C);document.addEventListener("DOMContentLoaded",fe);async function fe(){try{const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});a.currentTab=e,a.renderCallback=()=>p(a),await b(a),p(a),W(()=>b(a),U),ve(),se(),ye()}catch(e){console.error("[Popup] Initialization error:",e)}}function ve(){document.getElementById("searchInput").addEventListener("input",r=>{a.searchQuery=r.target.value.toLowerCase(),T(a),p(a)}),document.querySelectorAll(".filter-btn").forEach(r=>{r.addEventListener("click",c=>{const u=c.currentTarget;if(u.id==="archiveToggle"){a.showArchived=!a.showArchived,u.classList.toggle("active",a.showArchived);const h=u.querySelector(".archive-label");h&&(h.textContent=a.showArchived?"Active":"Archive"),p(a);return}document.querySelectorAll(".filter-btn:not(.archive-toggle)").forEach(h=>h.classList.remove("active")),u.classList.add("active"),a.currentFilter=u.dataset.filter,p(a)})}),document.querySelectorAll(".color-filter-btn").forEach(r=>{r.addEventListener("click",c=>{const u=c.currentTarget,h=u.dataset.color;a.selectedColors.includes(h)?(a.selectedColors=a.selectedColors.filter(v=>v!==h),u.classList.remove("active")):(a.selectedColors.push(h),u.classList.add("active")),T(a),p(a)})});const t=document.getElementById("clearFiltersBtn");t&&t.addEventListener("click",()=>{a.selectedColors=[],document.querySelectorAll(".color-filter-btn").forEach(c=>{c.classList.remove("active")});const r=document.getElementById("searchInput");r.value="",a.searchQuery="",t.style.display="none",p(a)}),document.getElementById("exportHighlights").addEventListener("click",()=>{z(a)});const n=document.getElementById("clearPageHighlights");n&&n.addEventListener("click",()=>{I("page",a)});const o=document.getElementById("clearAllHighlights");o&&o.addEventListener("click",()=>{I("all",a)});const i=document.getElementById("undoButton");i&&i.addEventListener("click",()=>{X(a)});const l=document.getElementById("shortcutsToggle"),s=document.getElementById("shortcutsList");l&&s&&(l.addEventListener("click",()=>{const r=s.style.display!=="none";s.style.display=r?"none":"block"}),document.addEventListener("click",r=>{!l.contains(r.target)&&!s.contains(r.target)&&(s.style.display="none")})),navigator.platform.toUpperCase().indexOf("MAC")>=0&&document.querySelectorAll(".platform-key").forEach(r=>{r.textContent==="Ctrl"&&(r.textContent="Cmd")})}
