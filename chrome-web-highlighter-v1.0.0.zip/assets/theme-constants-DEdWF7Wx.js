const r={primary:{dark:"rgba(1, 22, 39, 0.95)",darker:"rgba(1, 22, 39, 0.98)",light:"rgba(1, 22, 39, 0.75)",solid:"#011627"},text:{primary:"rgba(255, 255, 255, 0.9)",secondary:"rgba(255, 255, 255, 0.6)",tertiary:"rgba(255, 255, 255, 0.4)",inverse:"#1f2937"},surface:{glass:"rgba(255, 255, 255, 0.05)",glassHover:"rgba(255, 255, 255, 0.1)",border:"rgba(255, 255, 255, 0.1)",borderLight:"rgba(255, 255, 255, 0.2)",borderHover:"rgba(255, 255, 255, 0.3)"},highlights:{yellow:"#ffe066",green:"#6ee7b7",blue:"#93c5fd",pink:"#fca5a5"},highlightsBg:{yellow:"rgba(255, 224, 102, 0.3)",green:"rgba(110, 231, 183, 0.3)",blue:"rgba(147, 197, 253, 0.3)",pink:"rgba(252, 165, 165, 0.3)"},status:{error:"#ef4444",success:"#10b981",warning:"#f59e0b",info:"#3b82f6"},legacy:{purple:"#667eea",purpleDark:"#764ba2"}},a={blur:"10px",borderRadius:"8px",transition:"all 0.2s ease",shadowLarge:"0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)"},e={xs:"4px",sm:"8px",md:"12px",lg:"16px",xl:"20px"},o={background:r.surface.glass,backdropFilter:`blur(${a.blur})`,webkitBackdropFilter:`blur(${a.blur})`,border:`1px solid ${r.surface.border}`},i={highlightButton:{background:r.primary.light,backdropFilter:`blur(${a.blur})`,border:`1px solid ${r.surface.border}`,color:r.text.primary,padding:`${e.sm} ${e.lg}`,borderRadius:a.borderRadius,transition:a.transition},miniToolbar:{...o,padding:e.sm,borderRadius:a.borderRadius,boxShadow:a.shadowLarge},colorPicker:{...o,padding:e.md,borderRadius:a.borderRadius,gap:e.xs},popup:{header:{background:r.primary.darker,...o,borderBottom:`1px solid ${r.surface.border}`,padding:e.xl},body:{background:r.primary.dark,color:r.text.primary},card:{...o,padding:e.lg,borderRadius:a.borderRadius}}};function s(){return`
    :root {
      /* Colors */
      --color-primary-dark: ${r.primary.dark};
      --color-primary-darker: ${r.primary.darker};
      --color-primary-light: ${r.primary.light};
      --color-text-primary: ${r.text.primary};
      --color-text-secondary: ${r.text.secondary};
      --color-surface-glass: ${r.surface.glass};
      --color-surface-border: ${r.surface.border};
      
      /* Highlights */
      --color-highlight-yellow: ${r.highlights.yellow};
      --color-highlight-green: ${r.highlights.green};
      --color-highlight-blue: ${r.highlights.blue};
      --color-highlight-pink: ${r.highlights.pink};
      
      /* Effects */
      --effect-blur: ${a.blur};
      --effect-border-radius: ${a.borderRadius};
      --effect-transition: ${a.transition};
      
      /* Spacing */
      --spacing-xs: ${e.xs};
      --spacing-sm: ${e.sm};
      --spacing-md: ${e.md};
      --spacing-lg: ${e.lg};
      --spacing-xl: ${e.xl};
    }
  `}export{i as C,r as a,s as g};
